<nav class="navbar">
	<div class="mobile-menu">
		<div class="logo-container">
			<img src="https://drmarcelo.hectorsiman.com/wp-content/uploads/2023/08/logo.svg" alt="Dr. Marcelo">
		</div>
		<div class="mobile-menu-icon">

			<svg width="41" height="41" viewBox="0 0 41 41" fill="none" xmlns="http://www.w3.org/2000/svg">
				<path d="M10.25 2.92857C10.25 1.31122 11.1679 0 12.3 0H38.95C40.0821 0 41 1.31122 41 2.92857C41 4.54592 40.0821 5.85714 38.95 5.85714H12.3C11.1679 5.85714 10.25 4.54581 10.25 2.92857ZM38.95 17.5714H2.05C0.917856 17.5714 0 18.8828 0 20.5C0 22.1173 0.917856 23.4286 2.05 23.4286H38.95C40.0821 23.4286 41 22.1173 41 20.5C41 18.8828 40.0821 17.5714 38.95 17.5714ZM38.95 35.1429H20.5C19.3679 35.1429 18.45 36.4541 18.45 38.0714C18.45 39.6887 19.3679 41 20.5 41H38.95C40.0821 41 41 39.6887 41 38.0714C41 36.4541 40.0821 35.1429 38.95 35.1429Z" fill="#1E1E1E" />
			</svg>
		</div>
	</div>

	<ul class="nav-list">
		<!-- <li><a href="#">Home</a></li> -->
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#sobre-mim">Sobre mim</a></li>
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#tratamentos">Tratamentos</a></li>
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#depoimentos">Depoimentos</a></li>
		<li class="transition ease-in-out duration-300 schedule-li"><a href="https://www.doctoralia.com.br/marcelo-machado-lopes-2/psiquiatra/belo-horizonte?utm_source=site" class="schedule-appointment rounded-full bg-[#3A3A3A] hover:bg-[#5A5A5A]">Agendar Consulta</a></li>
		<span class="hidden"></span>
	</ul>

</nav>

<div class="mobile-menu-sidebar">

	<ul class="nav-list">
		<!-- <li><a href="#">Home</a></li> -->
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#sobre-mim">Sobre mim</a></li>
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#tratamentos">Tratamentos</a></li>
		<li class="transition ease-in-out duration-300 opacity-100"><a href="#depoimentos">Depoimentos</a></li>
		<li class="transition ease-in-out duration-300 opacity-100 schedule-li"><a href="https://www.doctoralia.com.br/marcelo-machado-lopes-2/psiquiatra/belo-horizonte?utm_source=site" class="schedule-appointment rounded-full bg-[#3A3A3A] border-1 hover:bg-[#5A5A5A]">Agendar Consulta</a></li>
	</ul>
</div>