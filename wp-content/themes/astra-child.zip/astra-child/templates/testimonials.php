<div class="testimonials owl-carousel owl-theme hidden-el from-down">
    <?php
    $args = array(
        'post_type' => 'testimonial',
        'posts_per_page' => -1,
    );

    $testimonial_query = new WP_Query($args);

    while ($testimonial_query->have_posts()) : $testimonial_query->the_post();
        $testimonial_name = get_the_title();
        $testimonial_content = get_the_content();
    ?>
        <div class="testimonial-card px-10 gap-7 text-center flex flex-col justify-center items-center">
            <h4 class="testimonial-name text-[#3c3231] font-bold">
                <?php echo esc_html($testimonial_name); ?>
            </h4>
            <p class="testimonial-content text-sm text-[#7a7a7a]">
                <?php echo esc_html($testimonial_content); ?>
            </p>
            <div class="stars-container flex justify-center">
                <img src="/wp-content/uploads/2023/08/starts.svg" alt="stars">
            </div>
        </div>
    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>
</div>