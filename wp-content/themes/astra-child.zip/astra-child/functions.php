<?php

/**
 * Astra Child Theme functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Astra Child
 * @since 1.0.0
 */

/**
 * Define Constants
 */
define('CHILD_THEME_ASTRA_CHILD_VERSION', '1.0.0');

/**
 * Enqueue styles
 */
function child_enqueue_styles()
{

	wp_enqueue_script('tailwindcss', "https://cdn.tailwindcss.com");
	wp_enqueue_script('custom', "/wp-content/themes/astra-child/js/custom.js");
	wp_enqueue_script('animated', "/wp-content/themes/astra-child/animated/animated.js");
	wp_enqueue_script('owl-carousel', "/wp-content/themes/astra-child/js/owl.carousel.min.js");
	wp_enqueue_style('astra-child-theme-css', '/wp-content/themes/astra-child/style.css', array('astra-theme-css'), CHILD_THEME_ASTRA_CHILD_VERSION, 'all');
	wp_enqueue_style('animated', '/wp-content/themes/astra-child/animated/animated.css');
	wp_enqueue_style('owl-carousel', '/wp-content/themes/astra-child/css/owl.theme.default.min.css');
	//wp_enqueue_style('swiper', 'https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css');
	//wp_enqueue_script('swiper', "https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js");
}

add_action('wp_enqueue_scripts', 'child_enqueue_styles', 15);


function mind_defer_scripts($tag, $handle, $src)
{
	$defer = array(
		'animated',
	);
	if (in_array($handle, $defer)) {
		return '<script src="' . $src . '" defer="defer" type="text/javascript"></script>' . "\n";
	}

	return $tag;
}
add_filter('script_loader_tag', 'mind_defer_scripts', 10, 3);

function get_navigation_menu($atts)
{
	ob_start();

	$file_path = 'templates/navigation-menu.php';
	include $file_path;
	$output = ob_get_clean();
	return $output;
}
add_shortcode('call_navigation_menu', 'get_navigation_menu');

function get_testimonials_carousel($atts)
{
	ob_start();

	$file_path = 'templates/testimonials.php';
	include $file_path;
	$output = ob_get_clean();
	return $output;
}
add_shortcode('call_testimonials_carousel', 'get_testimonials_carousel');

function get_deseases_grid($atts)
{
	ob_start();

	$file_path = 'templates/deseases-grid.php';
	include $file_path;
	$output = ob_get_clean();
	return $output;
}
add_shortcode('call_deseases_grid', 'get_deseases_grid');

function get_social_media($atts)
{
	ob_start();

	$file_path = 'templates/social-media.php';
	include $file_path;
	$output = ob_get_clean();
	return $output;
}
add_shortcode('call_social_media', 'get_social_media');


function get_services($atts)
{
	ob_start();

	$file_path = 'templates/services.php';
	include $file_path;
	$output = ob_get_clean();
	return $output;
}
add_shortcode('call_services', 'get_services');


function custom_testimonial_post_type()
{
	$labels = array(
		'name'               => _x('Depoimentos', 'Nome geral do tipo de post'),
		'singular_name'      => _x('Depoimento', 'Nome singular do tipo de post'),
		'add_new'            => _x('Adicionar Novo', 'Adicionar novo item'),
		'add_new_item'       => __('Adicionar Novo Depoimento'),
		'edit_item'          => __('Editar Depoimento'),
		'new_item'           => __('Novo Depoimento'),
		'all_items'          => __('Todos os Depoimentos'),
		'view_item'          => __('Ver Depoimento'),
		'search_items'       => __('Buscar Depoimentos'),
		'not_found'          => __('Nenhum depoimento encontrado'),
		'not_found_in_trash' => __('Nenhum depoimento encontrado na Lixeira'),
		'parent_item_colon'  => '',
		'menu_name'          => 'Depoimentos'
	);

	$args = array(
		'labels'        => $labels,
		'description'   => 'Tipo de post para depoimentos',
		'public'        => true,
		'menu_position' => 5,
		'menu_icon' 	=> 'dashicons-testimonial',
		'supports'      => array('title', 'editor', 'thumbnail'),
		'has_archive'   => true,
	);

	register_post_type('testimonial', $args);
}

add_action('init', 'custom_testimonial_post_type');
